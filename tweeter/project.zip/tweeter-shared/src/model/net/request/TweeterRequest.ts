export interface TweeterRequest {}
